package com.woongjin.intern.survey.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.woongjin.intern.member.dao.MemberDao;
import com.woongjin.intern.member.service.MService;
import com.woongjin.intern.survey.dao.SurveyDao;
import com.woongjin.intern.survey.dto.SurveyDto;
import com.woongjin.intern.survey.service.SurveyService;

@Controller
@RequestMapping("/survey")
public class SurveyController {
	@Autowired
	private SurveyDao dao;

	@Resource(name ="surveyService")
	private SurveyService surveyService;

	
	@RequestMapping(value="/insertSurvey.do",method=RequestMethod.POST)
	public String insertSurvey(SurveyDto dto) {
		
		dao.insertSurvey(dto);
		return "survey/resultSurvey";
	}

}
