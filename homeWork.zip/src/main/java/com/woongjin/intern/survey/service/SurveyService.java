package com.woongjin.intern.survey.service;

import com.woongjin.intern.survey.dto.SurveyDto;

public interface SurveyService {
	public void insertSurvey(SurveyDto dto);
}
