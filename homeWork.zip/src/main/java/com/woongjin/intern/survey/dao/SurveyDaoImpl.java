package com.woongjin.intern.survey.dao;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.woongjin.intern.survey.dto.SurveyDto;

@Repository
public class SurveyDaoImpl implements SurveyDao {

	@Autowired
	@Resource(name="sqlSession")
	private SqlSession query;
	private final static String MAPPER = "survey.surveyDao.";
	@Override
	public void insertSurvey(SurveyDto dto) {
		query.insert(MAPPER+"insertSurvey", dto);
		
	}

}
