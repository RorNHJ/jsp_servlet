package com.woongjin.intern.survey.dao;

import com.woongjin.intern.survey.dto.SurveyDto;

public interface SurveyDao {
	public void insertSurvey(SurveyDto dto);
}
