package com.woongjin.intern.board.service;

import org.springframework.ui.Model;

public class BModifyService implements BService {

	@Override
	public void execute(Model model) {
		// TODO Auto-generated method stub
		
	}

}
