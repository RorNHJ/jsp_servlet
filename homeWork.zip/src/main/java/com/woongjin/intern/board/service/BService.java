package com.woongjin.intern.board.service;

import org.springframework.ui.Model;

public interface BService {
	void execute(Model model);
}
