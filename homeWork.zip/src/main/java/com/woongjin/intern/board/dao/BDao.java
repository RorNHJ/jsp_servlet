package com.woongjin.intern.board.dao;

import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.woongjin.intern.board.dto.BDto;

public class BDao {
	
	public BDao() {
		try {
			Context context = new InitialContext();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	//�����ͺ��̽��� ��� �� ��ϵ��� �̾Ƽ� ����
	public ArrayList<BDto> list() {
		ArrayList<BDto> dtos = null;
		return dtos;
	}
	
	public void write(String mId, String bTitle,String bContent) {
		
	}
}
